function platform() {
  this.width = 100;
  this.height = 100;
  this.x = 650;
  this.y = 250;
      
      this.show = function() {
        image(img5, this.x,this.y);
      }
      
      
      
    }
